/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2;

import java.io.BufferedReader; 
import java.io.FileReader;
import java.io.IOException; 
import java.io.InputStreamReader;

public class p2
{ 
    public static void main(String[] args) throws IOException  
    { 
        BufferedReader reader =  
                   new BufferedReader(new InputStreamReader(System.in));
	String input = reader.readLine();
        
        postfixParse thisExpr = new postfixParse(input);
        
	while(input!=null)
	{
	System.out.println("The input is: "+input);
        System.out.println("The inorder traversal is: "+thisExpr.infix);
        System.out.println("The output of the expression is: "+thisExpr.out);
	input = reader.readLine();
	}
    } 
} 

class postfixParse implements treeReadInterface
{
    String [] postList = new String[100];
    String infix = "";
    float out = 0;
    exprTree tree;
    
    public postfixParse (String postfix) {
        build_expression_tree(postfix, postList);
    }
    
    // Builds exprTree and also returns an infix expression
    public String build_expression_tree(String postfix, String [] tokenList){
        
        // Parse input
        tokenList = postfix.split(" ");
        
        // Set up tree to be procedurally built
        tree = new exprTree(tokenList[tokenList.length-1]); // Root Created
        Node currentNode = tree.root;
        
        // Build tree by stepping from right end of postfix to left end
        int i  = tokenList.length-2;
        while (i >= 0) {
            // build tree
            if ("+-*/".contains(tokenList[i])) {
                currentNode.left = new Node(tokenList[i-1], currentNode);
                currentNode.right = new Node(tokenList[i-1], currentNode);
            }
            else 
            i--;
        }
        
        // return infix string
        infix = tree.root.readInfix("");
        return infix;
    }
    public int evaluate_expression_tree(String [] tokenList) {
        return 0;
    } 
}


/*  
 *  Below is an implementation of an expression tree, used to store expressions
 *  that use the four operators + - * / along with floating point numbers on 
 *  each leaf.
 */ 

class exprTree {
    Node root;
    
    public exprTree(String lastVal) {
        root = new Node(lastVal, null);
    }
} 

class Node {
    Node left;
    Node right;
    Node parent;
    String value;
    boolean needsEval = false;
    
    public Node(String val, Node parentNode) {
        parent = parentNode;
        value = val;
        if ("+-*/".contains(val)) {
            needsEval = true;
            }
        needsEval = false;
    }
    
    public float eval() {
        if (needsEval == false) {
            return Integer.parseInt(value);
        }
        else if (value == "*") {
            return (left.eval() * right.eval());
        }     
        else if (value == "/") {
            return (left.eval() / right.eval());
        }
        else if (value == "+") {
            return (left.eval() + right.eval());
        }
        else if (value == "-") {
            return (left.eval() - right.eval());
        }
        return -99999999; // ERROR ENCOUNTERED
    }
    
    public String readInfix(String readSoFar) {
        if (needsEval == false) {
            return readSoFar + value;
        }
        else if (value == "*" || value == "/") {
            return (readSoFar+left.readInfix("")+ " " +value+ " " 
                    +right.readInfix(""));
        }
        else if (value == "+" || value == "-") {
            return (readSoFar+ " ( " +left.readInfix("")+ " " +value+ " " 
                    +right.readInfix("")+ " )");
        }
        return "ERROR ENCOUNTERED";
    }
}