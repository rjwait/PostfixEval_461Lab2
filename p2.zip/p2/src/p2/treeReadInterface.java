/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2;

/**
 *
 * @author nca5101
 */
public interface treeReadInterface {   
    public void build_expression_tree(Node currentNode);
    public float evaluate_expression_tree(exprTree tree); 
}